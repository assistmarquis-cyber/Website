# Marquis Harmon — The Big Picture Arkitect
## Website build brief for Claude Code

Open this folder in Claude Code (desktop app → Code tab → open folder), then paste the prompt below.

---

## Prompt to paste into Claude Code

> Build my professional website from this folder. Read START-HERE.md fully first.
>
> Use the three HTML files in `design-reference/` as the exact visual reference: layout, copy, colors, fonts and spacing. They're design mockups, not production code, so rebuild them cleanly. Ignore any `{{primary}}` / `{{accent}}` template tags and the `support.js` script; use the color tokens listed below instead.
>
> Use Astro (static site, fast, good SEO). Make it mobile-first and match `HomeMobile.html` on phones. Put real content from `content/` where the mockups have [bracketed placeholders]; leave any placeholder I haven't supplied visibly marked so I can find it.
>
> Pages to build: Home, Enterprise Workshops, Keynotes, Executive Coaching, IRL Productions, About, and Contact (inquiry form). Give each keynote and workshop its own page with a descriptive title for search.
>
> Wire the inquiry form to Netlify Forms. Add basic SEO: page titles, meta descriptions, Open Graph image, sitemap, and schema.org Person markup.
>
> Show me a local preview first. After I approve, walk me through deploying to Netlify and connecting my domain step by step. I'm not a developer, so explain each command before running it.

---

## Brand rules

- The brand is spelled **Arkitect** with a K. Never "Architect."
- Tagline lockup: "The Big Picture Arkitect" in Fraunces, sentence case, normal letter spacing, with **"Ark"** in turquoise. Never all caps.
- Buyer is an enterprise L&D / HR / executive team. Tone: confident, plain, outcome-focused.
- Primary call to action: **Request availability** (red button). Secondary: **Download speaker one-sheet**.

## Design tokens

| Token | Value | Use |
|---|---|---|
| Primary | `#1B6663` | Turquoise: links, highlights, "Ark" |
| Accent | `#B8322A` | Red: primary CTA buttons only |
| Text | `#2A1D14` / `#35261B` | Warm brown |
| Muted text | `#6B5646` | Taglines, captions |
| Background | `#FBF8F3` | Off-white page |
| Section fill | `#EEF6F4` / `#D6EBE8` | Mint bands |
| Border | `#E6DDD0` | Hairlines |

- Headings: **Fraunces** (Google Fonts), weight 500
- Body: **Work Sans**, 400/500/600
- Corners 6–12px. 12-column grid, 112px desktop gutters.

## Site structure

- **Home:** hero, credibility band (UN, Harvard Business School + client logos), "The challenge" (3 buyer pain points), three offers, 7 Layers staircase, engagement model (Discover → Design → Deliver → Measure), client outcomes, about, memoir, inquiry form
- **Enterprise Workshops:** signature program "AI Adoption with the G.O.D. Framework," workshop cards (audience / format / group size), engagement model, outcome quote
- **Keynotes:** one page per talk
- **Executive Coaching:** the 7 Layer Strategy (names and shape public; methods stay private)
- **About:** third-person bio, downloadable full bio
- **Contact:** inquiry form fields: full name, work email, company, title, engagement type, audience size, date/timeframe, on-site/virtual/hybrid, objectives

## The 7 Layers (bottom to top)

1. Personal Identity Investigation
2. Research & Development
3. Personal Identity Coaching
4. Action Mapping
5. Team Building, Systems & Comms
6. Rapid Prototyping
7. Mojo

One-line descriptions under each layer in the mockup are drafts — replace with Marquis's own wording.

## Content to drop into `content/` before building

- `photos/` — stage shot, executive portrait, book cover
- `logos/` — venue and client logos you have permission to use
- `docs/` — speaker one-sheet PDF, full bio, `copy.md` with:
  - [ ] 7 layer one-liners in your own words
  - [ ] 2–3 workshop descriptions (title, 3 outcomes)
  - [ ] G.O.D. Framework program blurb
  - [ ] Keynote titles and descriptions
  - [x] Testimonials: Andrew Antar (Tune.FM), Amber Lace Moore (State of Maryland Parks Department), Mark W. (coaching client) — in the design files
  - [ ] Result metrics
  - [ ] Book blurb
  - [x] Inquiry response time: 48 hours
  - [x] Company legal name: Marquis Alan Experience LLC

## Domains

- Primary: **marquisharmon.com**
- Redirect to it: bigpicturearkitect.com, bigpicturearchitect.com (misspelling), plus any keyword domains registered

Live design canvas: https://claude.ai/artifact/FGZyfv2LxZGetjguVeV9hc

## Also in design-reference/

- `OneSheet.html` — speaker one-sheet (letter size). Export it to PDF and link it from every "Download speaker one-sheet" button.

## Content notes

- Name is **Marquis Harmon**.
- Workshops show no Format, Audience or Group size fields.
- G.O.D. Framework = Generator · Operator · Destroyer, a rapid prototyping environment.
- Do not show a city or location anywhere on the site.
- Keynotes: three core topics, one page each:
  - See the Whole Picture. Then Build It. (leadership and business development)
  - Ship It. Amplify Them. (AI thought management)
  - Second Chances, First Principles (creating social impact)
- IRL Productions: augmented and virtual reality galleries, live performance pop-ups and hackathons. Give it its own page.
- Photos are in content/photos with descriptive names. Hero uses stage-cop22-marrakech-podium.jpg; About and one-sheet use portrait-drapes (photo credit: LHT.HSE Creative Studio). Rigging photos suit the IRL Productions page; god-framework-diagram.jpg suits the Workshops page.
